from streaming.jobs.votes_streaming_job import StreamingJob


if __name__ == "__main__":
    job = StreamingJob()
    job.execute_job()